package BaseJava;
// Exercie 8
public class Voiture {
	private String marque;
	private String model;
	private String motorisation;

	// Conctructeur avec tous les parametres
	public Voiture(String marque, String model, String motorisation) {
		super();
		this.marque = marque;
		this.model = model;
		this.motorisation = motorisation;
	}

	// Constructeur avec 2 parametres
	public Voiture(String marque, String model) {
		super();
		this.marque = marque;
		this.model = model;
	}
	// Constructeur avec un seul parametres

	public Voiture(String marque) {
		super();
		this.marque = marque;
	}

	@Override
	public String toString() {
		return "Voiture [marque=" + marque + ", model=" + model + ", motorisation=" + motorisation + "]";
	}

	public String getMarque() {
		return marque;
	}

	public void setMarque(String marque) {
		this.marque = marque;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getMotorisation() {
		return motorisation;
	}

	public void setMotorisation(String motorisation) {
		this.motorisation = motorisation;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// on cree une voiture avec le constructeur qui initialise tous les parametres
		Voiture voiture1 = new Voiture("peugeot", "peugeot3008", "diesel");

		// cree une voiture avec le constructeur à 2 parametres

		Voiture voiture2 = new Voiture("renault", "megane");
		voiture2.setMotorisation("diesel"); // Ensuite on initialise le parametre motorisation

		// On cree une voiture avec le constructeur à un 1 seul parametres
		Voiture voiture3 = new Voiture("audi");
		voiture3.setModel("RS"); // on initialise les autres parametres en utilisant les setters
		voiture3.setMotorisation("Essence");

		// On affiche les trois voitures crées en utilisant la fonction toString()

		System.out.println(voiture1.toString());

		System.out.println(voiture2.toString());
		System.out.println(voiture3.toString());

	}

}
