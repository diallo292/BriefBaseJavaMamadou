/**
 * 
 */
/**
 * @author dial
 *
 */
module BriefBaseJava {
}